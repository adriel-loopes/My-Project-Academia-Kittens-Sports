﻿namespace My_Project_Academia.Views
{
    partial class Loading
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbProcessando = new System.Windows.Forms.Label();
            this.ProgressBar1 = new System.Windows.Forms.ProgressBar();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.Timer3 = new System.Windows.Forms.Timer(this.components);
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Timer4 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // lbProcessando
            // 
            this.lbProcessando.AutoSize = true;
            this.lbProcessando.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbProcessando.Location = new System.Drawing.Point(73, 28);
            this.lbProcessando.Name = "lbProcessando";
            this.lbProcessando.Size = new System.Drawing.Size(123, 23);
            this.lbProcessando.TabIndex = 0;
            this.lbProcessando.Text = "Processando...";
            // 
            // ProgressBar1
            // 
            this.ProgressBar1.Location = new System.Drawing.Point(25, 75);
            this.ProgressBar1.Name = "ProgressBar1";
            this.ProgressBar1.Size = new System.Drawing.Size(212, 21);
            this.ProgressBar1.TabIndex = 1;
            // 
            // Timer1
            // 
            this.Timer1.Enabled = true;
            this.Timer1.Interval = 10;
            this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // Timer3
            // 
            this.Timer3.Enabled = true;
            this.Timer3.Interval = 50;
            this.Timer3.Tick += new System.EventHandler(this.Timer3_Tick);
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Panel1.ForeColor = System.Drawing.Color.DarkCyan;
            this.Panel1.Location = new System.Drawing.Point(25, 75);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(202, 10);
            this.Panel1.TabIndex = 2;
            // 
            // Timer4
            // 
            this.Timer4.Enabled = true;
            this.Timer4.Tick += new System.EventHandler(this.Timer4_Tick);
            // 
            // Loading
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(271, 118);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.ProgressBar1);
            this.Controls.Add(this.lbProcessando);
            this.Name = "Loading";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Loading";
            this.Load += new System.EventHandler(this.Loading_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lbProcessando;
        private ProgressBar ProgressBar1;
        private System.Windows.Forms.Timer Timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer Timer3;
        private Panel Panel1;
        private System.Windows.Forms.Timer Timer4;
    }
}